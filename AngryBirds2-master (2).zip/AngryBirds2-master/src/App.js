import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';

const API_BASE = "http://localhost:5000"

function submitForm(contentType, data, setResponse) {
    axios({
        url: `${API_BASE}/upload`,
        method: 'POST',
        data: data,
        headers: {
            'Content-Type': contentType
        }
    }).then((response) => {
        setResponse(response.data);
    }).catch((error) => {
        setResponse("error");
    })
}

const API_BASE2 = "https://gateway.watsonplatform.net/visual-recognition/api/v3/classify?apikey=ShHmJkaFUgOpwMBPDgW4J1Av2TrZ2WUHiMchtn4Lauhp&version=2018-03-19"
function submitREST(contentType, data, setResponse) {
    axios({
        url: `${API_BASE2}`,
        method: 'POST',
        data: data,
        headers: {
        }
    }).then((response) => {
        setResponse(response.data);
    }).catch((error) => {
        setResponse("error");
    })
}

function App() {
    const [title, setTitle] = useState("Trackcondition_1919885376");
    const [file, setFile] = useState(null);
    const [desc, setDesc] = useState("");

    function uploadWithFormData(){
        const formData = new FormData();
        formData.append("classifier_ids", title);
        formData.append("images_file", file);

        submitForm("multipart/form-data", formData, (msg) => console.log(msg));
        
        submitREST("multipart/form-data", formData, (msg) => console.log(msg));
    }

    async function uploadWithJSON(){
        const toBase64 = file => new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });

        const data = {
            
            file: await toBase64(file)
            
        }

        submitForm("application/json", data, (msg) => console.log(data));
        submitREST("application/json", data, (msg) => console.log(msg));
    }

    return (
        <div className="App">
            <h2>Upload Track Image</h2>
            <form>
                <label>
                    File Title
                    <input type="text" vaue={title} 
                            onChange={(e) => { setTitle(e.target.value )}} 
                            placeholder="Give a title to your upload" />
                </label>

                <label>
                    File
                    <input type="file" name="file" onChange={(e) => setFile(e.target.files[0])} />
                </label>

                <label>
                    Description
                    <textarea value={desc} onChange={(e) => setDesc(e.target.value)}></textarea>
                </label>

                <input type="button" value="Upload as Form" onClick={uploadWithFormData} />
                <input type="button" value="Upload as JSON" onClick={uploadWithJSON}/>
            </form>
        </div>
    );
}

export default App;
